import React, { useState, useEffect } from "react";
import Navbar from "./components/Navbar";
import Introduction from "./components/Introduction";
import Day1 from "./components/Day1";
import Day2 from "./components/Day2";
import Day3 from "./components/Day3";
import Day4 from "./components/Day4";
import Day5 from "./components/Day5";
import ImportantNote from "./components/ImportantNote";
import RabatInfo from "./components/RabatInfo";
import MeknesInfo from "./components/MeknesInfo";
import FesInfo from "./components/FesInfo";
import TrajetsInsolitesNature from "./components/TrajetsInsolitesNature";

import IntroductionAr from "./components/IntroductionAr";
import Day1Ar from "./components/Day1Ar";
import Day2Ar from "./components/Day2Ar";
import Day3Ar from "./components/Day3Ar";
import Day4Ar from "./components/Day4Ar";
import Day5Ar from "./components/Day5Ar";
import ImportantNoteAr from "./components/ImportantNoteAr";
import RabatInfoAr from "./components/RabatInfoAr";
import MeknesInfoAr from "./components/MeknesInfoAr";
import FesInfoAr from "./components/FesInfoAr";
import TrajetsInsolitesNatureAr from "./components/TrajetsInsolitesNatureAr";

function App() {
  const [language, setLanguage] = useState("fr"); // fr ou ar

  useEffect(() => {
    document.documentElement.lang = language;
    document.documentElement.dir = language === "ar" ? "rtl" : "ltr";
  }, [language]);

  return (
    <div className={`App font-sans ${language === "ar" ? "font-arabic" : ""}`}>
      <Navbar setLanguage={setLanguage} currentLanguage={language} />
      <main className="container mx-auto p-4">
        {language === "fr" ? <Introduction /> : <IntroductionAr />}
        
        <h2 className="text-3xl font-bold my-6 text-center text-blue-600">
          {language === "fr" ? "Itinéraire Détaillé" : "البرنامج التفصيلي"}
        </h2>
        <div className="space-y-8">
          {language === "fr" ? <Day1 /> : <Day1Ar />}
          {language === "fr" ? <Day2 /> : <Day2Ar />}
          {language === "fr" ? <Day3 /> : <Day3Ar />}
          {language === "fr" ? <Day4 /> : <Day4Ar />}
          {language === "fr" ? <Day5 /> : <Day5Ar />}
        </div>
        
        {language === "fr" ? <ImportantNote /> : <ImportantNoteAr />}
        
        <h2 className="text-3xl font-bold my-8 text-center text-blue-600">
          {language === "fr" ? "Informations Complémentaires" : "معلومات إضافية"}
        </h2>
        <div className="space-y-8">
          {language === "fr" ? <RabatInfo /> : <RabatInfoAr />}
          {language === "fr" ? <MeknesInfo /> : <MeknesInfoAr />}
          {language === "fr" ? <FesInfo /> : <FesInfoAr />}
          {language === "fr" ? <TrajetsInsolitesNature /> : <TrajetsInsolitesNatureAr />}
        </div>
      </main>
      <footer className="bg-gray-800 text-white text-center p-4 mt-8">
        <p>
          {language === "fr" ? "© 2025 Voyage au Maroc. Tous droits réservés." : "© 2025 رحلة إلى المغرب. جميع الحقوق محفوظة."}
        </p>
      </footer>
    </div>
  );
}

export default App;

