import React from 'react';

const MarchesSouksInfoAr = () => {
  return (
    <div className="p-6 bg-white shadow-lg rounded-lg text-right" dir="rtl">
      <h2 className="text-3xl font-bold mb-6 text-center text-blue-700">استكشاف الأسواق التقليدية</h2>

      {/* Rabat */}
      <div className="mb-8">
        <h3 className="text-2xl font-semibold mb-3 text-blue-600">أسواق في الرباط</h3>
        <p className="mb-2 italic">المعلومات مبنية على مقال من StayHere.ma (مايو 2024).</p>
        
        <div className="mb-4 p-4 border-r-4 border-blue-500 bg-blue-50">
          <h4 className="text-xl font-semibold">السوق المركزي بالرباط</h4>
          <p><strong>الوصف:</strong> أجواء قاعات تقليدية، منتجات طازجة، بوابة دخول للمدينة القديمة.</p>
          <p><strong>مثالي لـ:</strong> الانغماس في الجو، المنتجات الطازجة.</p>
        </div>

        <div className="mb-4 p-4 border-r-4 border-blue-500 bg-blue-50">
          <h4 className="text-xl font-semibold">السوق الكبير</h4>
          <p><strong>الوصف:</strong> تنوع كبير في الأقمشة، فساتين مغربية تقليدية. سوق العبيد سابقاً.</p>
          <p><strong>مثالي لـ:</strong> الأقمشة، القفطان، الجلابة. تفاوض على الأسعار.</p>
        </div>

        <div className="mb-4 p-4 border-r-4 border-blue-500 bg-blue-50">
          <h4 className="text-xl font-semibold">القيسارية</h4>
          <p><strong>الوصف:</strong> متخصص في المجوهرات، من القطع النادرة إلى الأقل تكلفة.</p>
          <p><strong>مثالي لـ:</strong> المجوهرات الفضية، الذهبية، الأحجار شبه الكريمة.</p>
        </div>

        <div className="mb-4 p-4 border-r-4 border-blue-500 bg-blue-50">
          <h4 className="text-xl font-semibold">سوق الخميس</h4>
          <p><strong>الوصف:</strong> مجموعة متنوعة من النباتات. واحة خضراء في المدينة القديمة.</p>
          <p><strong>مثالي لـ:</strong> النباتات، الزهور.</p>
        </div>

        <div className="mb-4 p-4 border-r-4 border-blue-500 bg-blue-50">
          <h4 className="text-xl font-semibold">سوق العطارين</h4>
          <p><strong>الوصف:</strong> سوق التوابل، عطور عضوية، علاجات تقليدية.</p>
          <p><strong>مثالي لـ:</strong> التوابل، العطور، منتجات العناية الطبيعية.</p>
        </div>

        <div className="p-4 border-r-4 border-blue-500 bg-blue-50">
          <h4 className="text-xl font-semibold">سوق الغزل</h4>
          <p><strong>الوصف:</strong> تجارة الصوف المصبوغ للسجاد أو الملابس. واسع ومزدحم في نهاية الأسبوع.</p>
          <p><strong>مثالي لـ:</strong> الصوف، السجاد.</p>
        </div>
      </div>

      {/* Meknès */}
      <div className="mb-8">
        <h3 className="text-2xl font-semibold mb-3 text-blue-600">أسواق في مكناس</h3>
        <p className="mb-2 italic">المعلومات مبنية على موقع المجلس الإقليمي للسياحة بمكناس.</p>

        <div className="mb-4 p-4 border-r-4 border-blue-500 bg-blue-50">
          <h4 className="text-xl font-semibold">سوق لهديم</h4>
          <p><strong>الوصف:</strong> مشهور بالزيتون. تذوق قبل الاختيار.</p>
          <p><strong>مثالي لـ:</strong> الزيتون، المنتجات المحلية.</p>
        </div>

        <div className="mb-4 p-4 border-r-4 border-blue-500 bg-blue-50">
          <h4 className="text-xl font-semibold">سوق السكاكين</h4>
          <p><strong>الوصف:</strong> سكاكين، أدوات من الصفيح، أباريق شاي.</p>
          <p><strong>مثالي لـ:</strong> الحرف المعدنية، الأدوات التقليدية.</p>
        </div>

        <div className="mb-4 p-4 border-r-4 border-blue-500 bg-blue-50">
          <h4 className="text-xl font-semibold">سوق البزازين</h4>
          <p><strong>الوصف:</strong> سلال، خيزران. سلال مصنوعة يدوياً.</p>
          <p><strong>مثالي لـ:</strong> السلال، منتجات الخيزران.</p>
        </div>
        
        <div className="mb-4 p-4 border-r-4 border-blue-500 bg-blue-50">
          <h4 className="text-xl font-semibold">باب الجديد</h4>
          <p><strong>الوصف:</strong> آلات موسيقية، سوق للسلع الرخيصة والمستعملة.</p>
          <p><strong>مثالي لـ:</strong> الآلات التقليدية، التحف.</p>
        </div>

        <div className="mb-4 p-4 border-r-4 border-blue-500 bg-blue-50">
          <h4 className="text-xl font-semibold">سوق النجارين</h4>
          <p><strong>الوصف:</strong> ورش نجارة.</p>
          <p><strong>مثالي لـ:</strong> المنتجات الخشبية المنحوتة.</p>
        </div>

        <div className="mb-4 p-4 border-r-4 border-blue-500 bg-blue-50">
          <h4 className="text-xl font-semibold">سوق السبت</h4>
          <p><strong>الوصف:</strong> أحذية، أقمشة، ملابس.</p>
          <p><strong>مثالي لـ:</strong> البلغة، الأقمشة، الملابس.</p>
        </div>

        <div className="p-4 border-r-4 border-blue-500 bg-blue-50">
          <h4 className="text-xl font-semibold">سوق الحرير</h4>
          <p><strong>الوصف:</strong> أقمشة حريرية.</p>
          <p><strong>مثالي لـ:</strong> الحرير.</p>
          <p className="mt-2"><strong>الحرف العامة في مكناس:</strong> تطعيم المعادن، تطريز، دباغة.</p>
        </div>
      </div>

      {/* Fès */}
      <div>
        <h3 className="text-2xl font-semibold mb-3 text-blue-600">أسواق في فاس</h3>
        <p className="mb-2 italic">المعلومات مبنية على Barcelo.com ومصادر أخرى. فاس البالي سوق ضخم.</p>

        <div className="mb-4 p-4 border-r-4 border-blue-500 bg-blue-50">
          <h4 className="text-xl font-semibold">سوق الحناء</h4>
          <p><strong>الوصف:</strong> حناء، مستحضرات تجميل طبيعية.</p>
          <p><strong>مثالي لـ:</strong> الحناء، الكحل، الغسول.</p>
        </div>

        <div className="mb-4 p-4 border-r-4 border-blue-500 bg-blue-50">
          <h4 className="text-xl font-semibold">قيسرية الكفاح</h4>
          <p><strong>الوصف:</strong> أقدم سوق في فاس، تم تجديده. بازار كبير.</p>
          <p><strong>مثالي لـ:</strong> حرف متنوعة، أقمشة، هدايا تذكارية.</p>
        </div>

        <div className="mb-4 p-4 border-r-4 border-blue-500 bg-blue-50">
          <h4 className="text-xl font-semibold">سوق الصفارين (ساحة الصفارين)</h4>
          <p><strong>الوصف:</strong> أعمال النحاس، النحاس الأصفر. أباريق شاي، أوعية.</p>
          <p><strong>مثالي لـ:</strong> منتجات النحاس والنحاس الأصفر.</p>
        </div>

        <div className="mb-4 p-4 border-r-4 border-blue-500 bg-blue-50">
          <h4 className="text-xl font-semibold">سوق عين علو</h4>
          <p><strong>الوصف:</strong> منتجات جلدية.</p>
          <p><strong>مثالي لـ:</strong> البلغة، الحقائب الجلدية، البُوف.</p>
        </div>

        <div className="mb-4 p-4 border-r-4 border-blue-500 bg-blue-50">
          <h4 className="text-xl font-semibold">سوق العطارين (سوق التوابل)</h4>
          <p><strong>الوصف:</strong> توابل، زيتون، فواكه مجففة.</p>
          <p><strong>مثالي لـ:</strong> التوابل، رأس الحانوت.</p>
        </div>

        <div className="mb-4 p-4 border-r-4 border-blue-500 bg-blue-50">
          <h4 className="text-xl font-semibold">سوق الشماعين</h4>
          <p><strong>الوصف:</strong> فواكه مجففة، نوغا.</p>
          <p><strong>مثالي لـ:</strong> التمر، اللوز، نوغا فاس.</p>
        </div>

        <div className="mb-4 p-4 border-r-4 border-blue-500 bg-blue-50">
          <h4 className="text-xl font-semibold">سوق النجارين (سوق النجارين)</h4>
          <p><strong>الوصف:</strong> منتجات خشبية. بالقرب من متحف النجارين.</p>
          <p><strong>مثالي لـ:</strong> الصناديق، الصواني الخشبية المنحوتة.</p>
        </div>
        <p className="mt-2 p-4 border-r-4 border-blue-500 bg-blue-50"><strong>أسواق أخرى في فاس:</strong> سوق العشابين (دواجن)، سوق السكاكين (معدات الخيول)، سوق البلاغين (سوق الأقفال القديم)، سوق السراجين، سوق الحايك، سوق الملاح.</p>
        <p className="mt-2 p-4 border-r-4 border-blue-500 bg-blue-50"><strong>منتجات فاس النموذجية:</strong> الجلود، الفخار الأزرق، الأقمشة، التوابل، منتجات التجميل الطبيعية، الحرف الخشبية والمعدنية، السجاد.</p>
        <p className="mt-2 p-4 border-r-4 border-red-500 bg-red-50"><strong>نصيحة عامة لفاس:</strong> المدينة القديمة متاهة. تفاوض بهدوء واحترام.</p>
      </div>

    </div>
  );
};

export default MarchesSouksInfoAr;

