import React from 'react';

const Day1 = () => {
  return (
    <section id="day1" className="py-8">
      <h3 className="text-2xl font-bold mb-3">Jour 1 : Rabat, Cœur Historique et Moderne du Royaume</h3>
      <div className="space-y-4">
        <div>
          <h4 className="text-xl font-semibold">Matin :</h4>
          <p className="text-gray-700 leading-relaxed">
            Commencez votre exploration par la majestueuse <strong>Kasbah des Oudayas</strong>, une ancienne forteresse aux ruelles bleues et blanches offrant des vues spectaculaires sur l'océan Atlantique et l'embouchure du fleuve Bouregreg. Poursuivez avec la visite de la <strong>Tour Hassan</strong>, minaret emblématique d'une mosquée inachevée du XIIe siècle, et le somptueux <strong>Mausolée Mohammed V</strong>, un chef-d'œuvre de l'architecture marocaine moderne.
          </p>
        </div>
        <div>
          <h4 className="text-xl font-semibold">Déjeuner :</h4>
          <p className="text-gray-700 leading-relaxed">
            Suggestion libre. Vous trouverez de charmants restaurants dans la médina de Rabat ou près de la Kasbah pour savourer la cuisine locale.
          </p>
        </div>
        <div>
          <h4 className="text-xl font-semibold">Après-midi :</h4>
          <p className="text-gray-700 leading-relaxed">
            Plongez dans l'histoire à la <strong>Nécropole de Chellah</strong>, un site fascinant mêlant ruines romaines de l'antique Sala Colonia et vestiges d'une nécropole mérinide, le tout dans un cadre verdoyant où les cigognes ont élu domicile. Si le temps le permet, terminez par une promenade relaxante aux <strong>Jardins d'Essais Botaniques</strong> ou le long des quais aménagés du Bouregreg.
          </p>
        </div>
        <div>
          <h4 className="text-xl font-semibold">Soir :</h4>
          <p className="text-gray-700 leading-relaxed">
            Retour à votre logement à Rabat.
          </p>
        </div>
      </div>
    </section>
  );
};

export default Day1;

