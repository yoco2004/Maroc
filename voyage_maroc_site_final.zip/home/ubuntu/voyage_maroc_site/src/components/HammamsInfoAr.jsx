import React from 'react';

const HammamsInfoAr = () => {
  return (
    <div className="p-6 bg-white shadow-lg rounded-lg text-right" dir="rtl">
      <h2 className="text-3xl font-bold mb-6 text-center text-green-700">تجارب حمام أصيلة</h2>

      <div className="mb-8">
        <h3 className="text-2xl font-semibold mb-3 text-green-600">حمامات في الرباط</h3>
        <div className="mb-4 p-4 border-r-4 border-green-500 bg-green-50">
          <h4 className="text-xl font-semibold mb-2">حمام صالون ريتانيا</h4>
          <p><strong className="font-semibold">العنوان:</strong> شارع العلويين 22، شقة رقم 2، حي حسان، الرباط.</p>
          <p><strong className="font-semibold">الوصف (بناءً على رأي من عام 2016):</strong> يبدو أنه صالون يقدم خدمات الحمام بدلاً من حمام عام تقليدي. يذكر الرأي تجربة ممتعة مع تقشير بالصابون الأسود، كيس، غسيل الشعر، لف بالrhassoul وتدليك. استخدام رأس دش بدلاً من الدلاء التقليدية.</p>
          <p><strong className="font-semibold">المصدر:</strong> منتدى Routard</p>
          <p><strong className="font-semibold">ملاحظة:</strong> الرأي يعود لعام 2016، يجب التحقق مما إذا كان المكان لا يزال موجودًا وما إذا كانت الخدمات/الأسعار مماثلة.</p>
        </div>
        <div className="p-4 border-r-4 border-green-500 bg-green-50">
          <h4 className="text-xl font-semibold mb-2">حمامات محلية في الرباط (المدينة القديمة والمناطق المحيطة بها)</h4>
          <p>ذكرت مدونة "Away With The Steiners" العديد من الحمامات المحلية، التي تقدم تجربة أكثر تقليدية وبأسعار معقولة من المنتجعات الصحية الخاصة. تتراوح أسعار الدخول عادة بين 15 و 25 درهمًا، مع تكاليف إضافية للتقشير (50-150 درهمًا) أو باقات تشمل المنتجات.</p>
          <p className="mt-2"><strong className="font-semibold">في المدينة القديمة بالرباط:</strong></p>
          <ul className="list-disc list-inside mr-4">
            <li>حمام لعلو</li>
            <li>حمام الشرفاء (الدخول: 13 درهم، الباقة: 200 درهم)</li>
            <li>حمام بويبة</li>
            <li>حمام العطارين (الدخول: 15 درهم، التقشير: 60 درهم، التدليك والتقشير: 120 درهم)</li>
          </ul>
          <p className="mt-2"><strong className="font-semibold">خارج المدينة القديمة بالرباط:</strong></p>
          <ul className="list-disc list-inside mr-4">
            <li>حمام مراسة (الدخول: 23 درهم، التقشير: 70 درهم، الباقة: 150 درهم)</li>
            <li>حمام تكتاك (الدخول: 15 درهم، التقشير: 50 درهم، الباقة: 150 درهم)</li>
          </ul>
          <p className="mt-2"><strong className="font-semibold">نصائح عامة للحمامات المحلية:</strong></p>
          <ul className="list-disc list-inside mr-4">
            <li><strong className="font-semibold">ما يجب إحضاره:</strong> ملابس احتياطية، ملابس داخلية، أدوات نظافة، منشفة.</li>
            <li><strong className="font-semibold">أشياء متوفرة للشراء:</strong> قفاز تقشير (كيس) ~10 دراهم، صابون أسود (صابون بلدي) ~2 درهم، شامبو.</li>
            <li><strong className="font-semibold">الإكرامية:</strong> 10-20% للشخص الذي يعتني بك.</li>
            <li><strong className="font-semibold">الملابس:</strong> النساء بالملابس الداخلية (سروال داخلي). الرجال بالملابس الداخلية أو السراويل القصيرة.</li>
          </ul>
          <p className="mt-2"><strong className="font-semibold">المصدر:</strong> Away With The Steiners</p>
          <p><strong className="font-semibold">ملاحظة:</strong> الأسعار والمعلومات من أبريل 2025 (حسب المقال). تحقق في الموقع.</p>
        </div>
      </div>

      <div className="mb-8">
        <h3 className="text-2xl font-semibold mb-3 text-green-600">حمامات في مكناس</h3>
        <p className="mb-2 italic">البحث عن معلومات محددة وحديثة حول الحمامات التقليدية ذات الأسعار المعقولة في مكناس جارٍ. قد يكون الوصول إلى مصادر مثل TripAdvisor صعبًا في بعض الأحيان ولا تسرد مدونات السفر دائمًا عناوين دقيقة.</p>
        <div className="p-4 border-r-4 border-green-500 bg-green-50">
          <h4 className="text-xl font-semibold mb-2">مسارات البحث والمعلومات العامة:</h4>
          <ul className="list-disc list-inside mr-4">
            <li><strong className="font-semibold">أكواسبا (مكناس):</strong> مذكور في TripAdvisor. رأي قديم (100 درهم للحمام المغربي). تحقق من الآراء الحديثة.</li>
            <li><strong className="font-semibold">بوذا حمام مكناس:</strong> يوجد موقع على شبكة الإنترنت. طقوس تقليدية/حديثة. تحقق من الأسعار والآراء.</li>
            <li><strong className="font-semibold">حمام تركي مكناس (فيسبوك):</strong> توجد صفحة على فيسبوك. ابحث عن الآراء والأسعار ونوع التجربة.</li>
            <li><strong className="font-semibold">البحث المحلي / السؤال في الموقع:</strong> استراتيجية موصى بها للعثور على عناوين أصيلة وبأسعار معقولة غير مدرجة عبر الإنترنت.</li>
          </ul>
          <p className="mt-2"><strong className="font-semibold">ملاحظة:</strong> تحقق من حداثة المعلومات والآراء.</p>
        </div>
      </div>

      <div>
        <h3 className="text-2xl font-semibold mb-3 text-green-600">حمامات في فاس</h3>
        <p className="mb-2 italic">قد يكون الوصول إلى بعض منصات الآراء محدودًا، ولكن يمكن لمدونات السفر والتوصيات المحلية تقديم أدلة.</p>
        <div className="p-4 border-r-4 border-green-500 bg-green-50">
          <h4 className="text-xl font-semibold mb-2">مسارات البحث والمعلومات العامة:</h4>
          <ul className="list-disc list-inside mr-4">
            <li><strong className="font-semibold">حمام مرنيسي وسبا (فاس):</strong> مذكور في TripAdvisor. آراء متباينة. راجع الآراء الحديثة.</li>
            <li><strong className="font-semibold">تجربة حمام في المدينة القديمة (مدونة "moicestclo.fr"):</strong> مقال من عام 2019 يذكر حمام + تدليك مقابل 450 درهم. لم يتم تحديد الاسم.</li>
            <li><strong className="font-semibold">حمام بلدي في حي مولاي إدريس (موصى به من قبل رياض جامع):</strong> معلومات من عام 2018. لا توجد تفاصيل عن الاسم/السعر.</li>
            <li><strong className="font-semibold">يوبا سين سبا حمام تدليك فاس (فيسبوك):</strong> صفحة فيسبوك مع آراء إيجابية حول التدليك. تحقق من الحمام التقليدي والأسعار.</li>
            <li><strong className="font-semibold">البحث المحلي / السؤال في الموقع:</strong> نهج ممتاز لفاس أيضًا.</li>
          </ul>
          <p className="mt-2"><strong className="font-semibold">ملاحظة عامة:</strong> مزيج من الخيارات في فاس (منتجعات سياحية، حمامات محلية). تحقق من الآراء الحديثة والأسعار ونوع التجربة.</p>
        </div>
      </div>

    </div>
  );
};

export default HammamsInfoAr;

