import React from 'react';

const TrajetsInsolitesNature = () => {
  const trajets = [
    {
      title: "Volubilis (proche de Meknès)",
      description: "Site archéologique romain, avec des vestiges d’une cité antique, temple de Jupiter, thermes, et mosaïques bien conservées.",
      pertinence: "Incontournable historique, déjà identifié lors de la collecte pour Meknès, mais à bien positionner sur un trajet."
    },
    {
      title: "Gouffre de Friouato (région de Taza)",
      description: "Seul gouffre aménagé du Maroc, de taille exceptionnelle (20m de large, 150m de profondeur). Accessible par un escalier le long de la paroi, avec stalactites et stalagmites.",
      pertinence: "Lieu naturel et insolite, à évaluer en fonction de la distance et du temps disponible sur un trajet vers Fès ou depuis Fès."
    },
    {
      title: "Lac Aguelmam Azigza (région de Khénifra)",
      description: "Lac situé dans un cadre naturel de montagnes et forêts, propice à la randonnée.",
      pertinence: "Site naturel intéressant, à considérer pour une escapade nature si l’itinéraire le permet."
    },
    {
      title: "Ifrane et ses environs (Moyen Atlas)",
      description: "Ville de montagne surnommée \"la petite Suisse marocaine\" pour son architecture et son climat. Proximité du Parc National d’Ifrane avec ses cédraies (cèdre Gouraud), macaques de Barbarie, et lacs (Dayet Aoua).",
      pertinence: "Nature et dépaysement, peut constituer une excursion d’une journée ou une étape sur un trajet plus long."
    },
    {
      title: "Moulay Idriss Zerhoun (proche de Meknès et Volubilis)",
      description: "Ville sainte perchée sur une colline, abritant le mausolée d’Idriss Ier. Ville pittoresque avec des vues panoramiques.",
      pertinence: "Site historique et culturel majeur, souvent visité en combinaison avec Volubilis."
    },
    {
      title: "Forêt de la Maâmora (entre Rabat et Kénitra)",
      description: "Grande forêt de chênes-lièges. Peut offrir une halte nature.",
      pertinence: "Nature, facile d’accès sur le trajet."
    },
    {
      title: "Ville de Khémisset (sur la route entre Rabat et Meknès)",
      description: "Ville connue pour son souk hebdomadaire et son artisanat berbère (tapis notamment). Moins touristique, elle peut offrir une expérience plus authentique.",
      pertinence: "Culture locale et authenticité."
    },
    {
      title: "Ville de Séfrou (proche de Fès)",
      description: "Ancienne ville avec une médina, des cascades (cascade de l’Oued Aggaï), et une culture juive historique. Connue pour sa fête des cerises.",
      pertinence: "Nature et culture, proche de Fès."
    }
  ];

  return (
    <section id="trajets-insolites-nature" className="py-8 bg-green-50">
      <div className="container mx-auto px-4">
        <h3 className="text-2xl font-bold mb-4 text-center">Lieux Insolites et Naturels sur les Trajets</h3>
        <p className="text-gray-600 text-sm mb-4 text-center">Informations extraites de "Le Maroc Insolite : 17 lieux (complètement) décalés à visiter !" et d'autres recherches.</p>
        <div className="grid md:grid-cols-2 gap-6">
          {trajets.map((item, index) => (
            <div key={index} className="bg-white p-6 rounded-lg shadow-md">
              <h4 className="text-xl font-semibold mb-2 text-green-700">{item.title}</h4>
              <p className="text-gray-700 leading-relaxed mb-1"><strong className="font-medium">Description :</strong> {item.description}</p>
              <p className="text-gray-700 leading-relaxed"><strong className="font-medium">Pertinence :</strong> {item.pertinence}</p>
            </div>
          ))}
        </div>
        <p className="text-sm text-gray-600 mt-4 text-center">Il faudra vérifier la localisation exacte et la faisabilité d’intégrer ces lieux dans des excursions journalières avec retour à Rabat.</p>
      </div>
    </section>
  );
};

export default TrajetsInsolitesNature;

