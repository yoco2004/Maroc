import React from 'react';

const MeknesInfoAr = () => {
  return (
    <section id="meknes-info-ar" className="py-8 bg-gray-50" dir="rtl">
      <div className="container mx-auto px-4">
        <h3 className="text-2xl font-bold mb-3">مكناس - المواقع التاريخية والطبيعية وغير المألوفة</h3>
        
        <div className="mb-6">
          <h4 className="text-xl font-semibold mb-2">مدينة مكناس التاريخية (اليونسكو)</h4>
          <p className="text-gray-700 leading-relaxed">
            تأسست في القرن الحادي عشر على يد المرابطين، وأصبحت مكناس عاصمة تحت حكم مولاي إسماعيل (1672-1727). لقد جعلها مدينة رائعة على الطراز الإسباني-المغربي، محاطة بأسوار عالية وأبواب ضخمة. وهي تشهد على تحالف الأساليب الإسلامية والأوروبية في القرن السابع عشر.
          </p>
          <p className="text-gray-700 leading-relaxed mt-2">
            تضم المدينة التاريخية المدينة القديمة والمدينة الإمبراطورية، مع معالم رئيسية مثل المساجد والحمامات والقصور والمخازن والأسوار الضخمة التي يصل ارتفاعها إلى 15 مترًا. وهي توضح الهندسة المعمارية الترابية (الطابية) للمدن جنوب الصحراء الكبرى في المغرب العربي.
          </p>
          <p className="text-sm text-gray-600 mt-1">المصدر: مركز التراث العالمي لليونسكو</p>
        </div>

        <div className="mb-6">
          <h4 className="text-xl font-semibold mb-2">أماكن غير مألوفة في مكناس</h4>
          <h5 className="text-lg font-semibold mb-1">حبس قارا، السجن القديم تحت الأرض</h5>
          <p className="text-gray-700 leading-relaxed">
            متاهة حقيقية تحت المدينة، داخل أسوار القصبة الإسماعيلية. تقول الأسطورة أن سجينًا برتغاليًا يدعى قارا بناه ليشتري حريته، مما أدى إلى إنشاء مساحة قادرة على استيعاب أكثر من 40 ألف سجين وتمتد لمسافة كيلومترات. يُطلق عليه أيضًا "سجن المسيحيين"، وكان يستخدم لسجن أسرى الحرب. يتم الوصول إليه عن طريق درج صغير يؤدي إلى عالم سفلي غامض.
          </p>
          <p className="text-sm text-gray-600 mt-1">المصدر: Le360.ma</p>
        </div>

        <div>
          <h4 className="text-xl font-semibold mb-2">الطبيعة حول مكناس</h4>
          <p className="text-gray-700 leading-relaxed mb-2">
            خارج أسوارها، تقدم مكناس مناطق داخلية غنية بالمساحات الطبيعية، ولا سيما سهل سايس الذي يفتح على الأطلس المتوسط.
          </p>
          <ul className="list-disc list-inside space-y-1 mr-4">
            <li><strong>جبال الأطلس المتوسط:</strong> أشجار الأرز الشامخة، مصدر الأنهار التي تشكل البحيرات والينابيع.</li>
            <li><strong>منابع أولماس وفيتيل:</strong> تشتهر بخصائصها المنشطة.</li>
            <li><strong>مغارة الأسد بالحاجب:</strong> معلم طبيعي مع إطلالة بانورامية على سهل سايس.</li>
            <li><strong>البحيرات الجبلية:</strong> مياه نقية وعذبة، مثالية للاسترخاء أو صيد الأسماك.</li>
            <li><strong>سهل سايس:</strong> سهل خصب واسع يوفر مناظر طبيعية مفتوحة.</li>
          </ul>
          <p className="text-gray-700 leading-relaxed mt-2">
            يمكن استكشاف هذه المواقع سيرًا على الأقدام أو بالدراجة أو على ظهور الخيل.
          </p>
          <p className="text-sm text-gray-600 mt-1">المصدر: المكتب الوطني المغربي للسياحة</p>
        </div>

      </div>
    </section>
  );
};

export default MeknesInfoAr;

