import React from 'react';

const Day4 = () => {
  return (
    <section id="day4" className="py-8">
      <h3 className="text-2xl font-bold mb-3">Jour 4 : Escapade Nature et Découvertes Authentiques entre Rabat et Meknès</h3>
      <div className="space-y-4">
        <div>
          <h4 className="text-xl font-semibold">Matin :</h4>
          <p className="text-gray-700 leading-relaxed">
            Pour une journée plus axée sur la nature et les découvertes locales, commencez par la visite des <strong>Jardins Exotiques de Bouknadel</strong> (situés entre Rabat et Kénitra), un havre de paix offrant une incroyable diversité de plantes du monde entier.
            <br />
            Poursuivez ensuite vers <strong>Khémisset</strong> (environ 1h de route depuis les jardins). Cette ville est réputée pour son grand souk hebdomadaire (traditionnellement le mardi, à vérifier) et son artisanat berbère, notamment les tapis. C'est une occasion de découvrir une ambiance plus locale et moins touristique.
          </p>
        </div>
        <div>
          <h4 className="text-xl font-semibold">Déjeuner :</h4>
          <p className="text-gray-700 leading-relaxed">
            Suggestion libre à Khémisset ou prévoyez un pique-nique.
          </p>
        </div>
        <div>
          <h4 className="text-xl font-semibold">Après-midi :</h4>
          <p className="text-gray-700 leading-relaxed">
            Explorez une partie de la <strong>Forêt de la Maâmora</strong>, la plus grande forêt de chênes-lièges du Maroc. Vous pourrez y faire une petite randonnée ou simplement profiter du calme de la nature.
          </p>
        </div>
        <div>
          <h4 className="text-xl font-semibold">Fin d'après-midi :</h4>
          <p className="text-gray-700 leading-relaxed">
            Retour tranquille à Rabat.
          </p>
        </div>
      </div>
    </section>
  );
};

export default Day4;

