import React from 'react';

const SuggestionsCadeauxAr = () => {
  return (
    <div className="p-6 bg-white shadow-lg rounded-lg text-right" dir="rtl">
      <h2 className="text-3xl font-bold mb-6 text-center text-purple-700">أفكار هدايا مغربية نموذجية للعائلة</h2>
      <p className="mb-4 text-lg text-gray-700">يزخر المغرب بكنوز حرفية ومنتجات محلية ستكون هدايا فريدة لا تُنسى لأحبائك. استكشف الأسواق النابضة بالحياة في الرباط ومكناس وفاس لتدليل زوجتك وأطفالك.</p>

      <div className="mb-8">
        <h3 className="text-2xl font-semibold mb-3 text-purple-600">للسيدة: أناقة ورفاهية</h3>
        <div className="space-y-3 text-gray-600">
          <p>فكري في أناقة <strong>القفطان</strong> أو <strong>الجلابة</strong> من الحرير أو القطن المطرز بدقة (سوق الكبير في الرباط، سوق السبت في مكناس/فاس).</p>
          <p><strong>المجوهرات البربرية الفضية</strong> (قيسارية الرباط، أسواق فاس) المزينة بالأحجار شبه الكريمة هي خيار رائع.</p>
          <p>لرفاهيتها، اختاري <strong>منتجات التجميل الطبيعية</strong>: <strong>زيت الأركان</strong>، <strong>الصابون الأسود</strong>، <strong>الغسول</strong>، ماء الورد، الكحل (سوق العطارين في الرباط، أسواق التوابل في فاس).</p>
          <p><strong>حقيبة جلدية</strong> مصنوعة يدوياً، <strong>بلغة</strong> ملونة (سوق عين علو في فاس)، <strong>فخار فاس</strong> الجميل (السيراميك الأزرق)، أو أشياء من <strong>النحاس المنقوش</strong> (سوق الصفارين في فاس) هي أيضاً خيارات ممتازة.</p>
        </div>
      </div>

      <div className="mb-8">
        <h3 className="text-2xl font-semibold mb-3 text-purple-600">للأطفال: حرف يدوية مرحة وهدايا تذكارية ساحرة</h3>
        <div className="space-y-3 text-gray-600">
          <p><strong>الألعاب الخشبية</strong> المصنوعة محلياً (سيارات صغيرة، حيوانات، آلات موسيقية مصغرة) هي خيار ممتاز (سوق النجارين في فاس/مكناس).</p>
          <p><strong>بلغة جلدية صغيرة</strong> ملونة تناسب حجمهم ستسعدهم.</p>
          <p><strong>الآلات الموسيقية التقليدية</strong> مثل الدربوكة أو القراقب (سوق بالقرب من باب الجديد في مكناس) ممتعة وتعريفية.</p>
          <p>للفتيات الصغيرات، <strong>دمى جميلة بأزياء تقليدية</strong> أو <strong>مجوهرات خرز ملونة</strong>.</p>
          <p><strong>الصناديق الخشبية المزخرفة</strong> (خشب العرعار، الليمون) من سوق النجارين يمكن أن تكون صناديق كنوز جميلة.</p>
          <p>لا تنسَ <strong>الحلويات</strong>: الحلويات المغربية، النوغا (سوق الشماعين في فاس).</p>
          <p><strong>سجادة بربرية</strong> صغيرة ملونة لغرفتهم يمكن أن تكون هدية أصلية ودائمة.</p>
        </div>
      </div>

      <div>
        <h3 className="text-2xl font-semibold mb-3 text-purple-600">نصائح لمشترياتك:</h3>
        <ul className="list-disc list-inside space-y-2 text-gray-600 mr-4">
          <li><strong>تفاوض بابتسامة:</strong> هذا جزء من تجربة الأسواق.</li>
          <li><strong>خذ وقتك:</strong> تجول، قارن الأسعار والجودة.</li>
          <li><strong>فضل الحرف اليدوية المحلية:</strong> ابحث عن الورش التي يعمل فيها الحرفيون.</li>
          <li><strong>تحقق من الجودة:</strong> افحص المنتجات بعناية (الجلود، الخياطة، دقة المجوهرات).</li>
        </ul>
        <p className="mt-4 text-lg text-gray-700">باختيارك هدايا من الأسواق، فإنك تدعم الحرف اليدوية المحلية وتقدم لعائلتك هدايا تذكارية أصيلة ومشبعة بروح المغرب.</p>
      </div>

    </div>
  );
};

export default SuggestionsCadeauxAr;

