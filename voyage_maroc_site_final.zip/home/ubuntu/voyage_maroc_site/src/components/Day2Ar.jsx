import React from 'react';

const Day2Ar = () => {
  return (
    <section id="day2-ar" className="py-8" dir="rtl">
      <h3 className="text-2xl font-bold mb-3">اليوم الثاني: مكناس، العظمة الإمبراطورية، وآثار وليلي الرومانية</h3>
      <div className="space-y-4">
        <div>
          <h4 className="text-xl font-semibold">الصباح:</h4>
          <p className="text-gray-700 leading-relaxed">
            الانطلاق صباحاً باتجاه <strong>وليلي</strong> (المسافة تستغرق حوالي ساعة و 45 دقيقة إلى ساعتين). استكشفوا هذا الموقع الأثري المصنف ضمن التراث العالمي لليونسكو، وهو أحد أفضل المدن الرومانية المحفوظة في شمال إفريقيا، بفسيفسائه وقوس النصر ومعابده.
            <br />
            ثم واصلوا إلى مدينة <strong>مولاي إدريس زرهون</strong> المقدسة، الواقعة على تلة وتوفر إطلالة بانورامية على المنطقة. إنه مكان حج مهم في المغرب.
          </p>
        </div>
        <div>
          <h4 className="text-xl font-semibold">الغداء:</h4>
          <p className="text-gray-700 leading-relaxed">
            اقتراح حر في مولاي إدريس أو عند الوصول إلى مكناس.
          </p>
        </div>
        <div>
          <h4 className="text-xl font-semibold">بعد الظهر:</h4>
          <p className="text-gray-700 leading-relaxed">
            اكتشاف <strong>مكناس</strong>، المدينة الإمبراطورية للسلطان مولاي إسماعيل. استمتعوا بجمال <strong>باب منصور</strong> الضخم، أحد أجمل أبواب المغرب، وتجولوا في <strong>ساحة الهديم</strong> الحيوية، وقوموا بزيارة <strong>ضريح مولاي إسماعيل</strong>. للمسة من الغرابة، انزلوا إلى سجن <strong>حبس قارا</strong> الغامض تحت الأرض.
          </p>
        </div>
        <div>
          <h4 className="text-xl font-semibold">آخر المساء:</h4>
          <p className="text-gray-700 leading-relaxed">
            العودة إلى الرباط (المسافة تستغرق حوالي ساعة و 45 دقيقة إلى ساعتين).
          </p>
        </div>
      </div>
    </section>
  );
};

export default Day2Ar;

