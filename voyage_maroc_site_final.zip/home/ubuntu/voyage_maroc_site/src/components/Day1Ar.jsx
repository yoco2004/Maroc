import React from 'react';

const Day1Ar = () => {
  return (
    <section id="day1-ar" className="py-8" dir="rtl">
      <h3 className="text-2xl font-bold mb-3">اليوم الأول: الرباط، قلب المملكة التاريخي والحديث</h3>
      <div className="space-y-4">
        <div>
          <h4 className="text-xl font-semibold">الصباح:</h4>
          <p className="text-gray-700 leading-relaxed">
            ابدأوا استكشافكم بزيارة <strong>قصبة الأوداية</strong> المهيبة، وهي قلعة قديمة بأزقتها البيضاء والزرقاء توفر إطلالات خلابة على المحيط الأطلسي ومصب نهر أبي رقراق. تابعوا بزيارة <strong>صومعة حسان</strong>، المئذنة الرمزية لمسجد غير مكتمل من القرن الثاني عشر، و<strong>ضريح محمد الخامس</strong> الفخم، تحفة من العمارة المغربية الحديثة.
          </p>
        </div>
        <div>
          <h4 className="text-xl font-semibold">الغداء:</h4>
          <p className="text-gray-700 leading-relaxed">
            اقتراح حر. ستجدون مطاعم ساحرة في مدينة الرباط القديمة أو بالقرب من القصبة لتذوق المأكولات المحلية.
          </p>
        </div>
        <div>
          <h4 className="text-xl font-semibold">بعد الظهر:</h4>
          <p className="text-gray-700 leading-relaxed">
            انغمسوا في التاريخ في <strong>مقبرة شالة</strong>، وهو موقع رائع يمزج بين الآثار الرومانية لمدينة سلا كولونيا القديمة وبقايا مقبرة مرينية، كل ذلك في إطار أخضر حيث استقرت طيور اللقلق. إذا سمح الوقت، اختموا بنزهة مريحة في <strong>حدائق التجارب النباتية</strong> أو على طول الأرصفة المجهزة لنهر أبي رقراق.
          </p>
        </div>
        <div>
          <h4 className="text-xl font-semibold">المساء:</h4>
          <p className="text-gray-700 leading-relaxed">
            العودة إلى مكان إقامتكم في الرباط.
          </p>
        </div>
      </div>
    </section>
  );
};

export default Day1Ar;

