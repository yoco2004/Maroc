import React from 'react';

const FesInfo = () => {
  return (
    <section id="fes-info" className="py-8 bg-gray-50">
      <div className="container mx-auto px-4">
        <h3 className="text-2xl font-bold mb-3">Fès - Sites Historiques et Naturels</h3>
        
        <div className="mb-6">
          <h4 className="text-xl font-semibold mb-2">Médina de Fès (UNESCO)</h4>
          <p className="text-gray-700 leading-relaxed">
            Fondée au IXe siècle, Fès a connu sa période faste aux XIIIe et XIVe siècles sous la dynastie mérinide. Le tissu urbain et les monuments essentiels (médersas, fondouks, palais, mosquées, fontaines) datent de cette période. Malgré le transfert de la capitale à Rabat en 1912, Fès reste la capitale culturelle et spirituelle du Maroc.
          </p>
          <p className="text-gray-700 leading-relaxed mt-2">
            La médina de Fès, l'une des plus vastes et mieux conservées du monde arabo-musulman, comprend Fès el-Bali (l'ancienne ville) et Fès Jedid (la nouvelle ville, fondée au XIIIe siècle, abritant le palais royal). Elle témoigne d'une grande variété de formes architecturales et de paysages urbains, résultat de plus de dix siècles de développement et d'influences diverses (andalouses, orientales, africaines).
          </p>
          <p className="text-sm text-gray-600 mt-1">Source: UNESCO World Heritage Centre</p>
        </div>

        <div>
          <h4 className="text-xl font-semibold mb-2">Nature aux Alentours de Fès</h4>
          <p className="text-gray-700 leading-relaxed mb-2">
            Fès est entourée de paysages naturels attrayants, notamment grâce à sa proximité avec le Moyen Atlas.
          </p>
          <ul className="list-disc list-inside space-y-1">
            <li><strong>Plaine du Saïss :</strong> La ville surplombe cette vaste plaine qui s'ouvre sur les massifs du Moyen Atlas.</li>
            <li><strong>Massifs du Moyen Atlas :</strong> Forêts, lacs et tranquillité, idéals pour une évasion nature.</li>
            <li><strong>Lac Dayet Aoua :</strong> À quelques kilomètres de Fès, propice aux randonnées (à cheval ou à pied) et activités nautiques (pédalo).</li>
            <li><strong>Forêts d'Immouzer :</strong> Cadre naturel préservé non loin de Fès.</li>
          </ul>
          <p className="text-gray-700 leading-relaxed mt-2">
            Ces sites permettent de combiner la découverte culturelle de Fès avec des escapades en pleine nature.
          </p>
          <p className="text-sm text-gray-600 mt-1">Source: Office National Marocain du Tourisme</p>
        </div>

      </div>
    </section>
  );
};

export default FesInfo;

