import React from 'react';
import { Menu, Transition } from '@headlessui/react';
import { ChevronDownIcon, GlobeAltIcon } from '@heroicons/react/20/solid'; // Assurez-vous d'avoir heroicons

const Navbar = ({ setPage, setLanguage, currentLanguage }) => {
  const frenchPages = [
    { name: 'Accueil', id: 'introduction' },
    { name: 'Jour 1: Rabat & Salé', id: 'day1' },
    { name: 'Jour 2: Volubilis & Moulay Idriss', id: 'day2' },
    { name: 'Jour 3: Meknès', id: 'day3' },
    { name: 'Jour 4: Fès (Partie 1)', id: 'day4' },
    { name: 'Jour 5: Fès (Partie 2) & Retour', id: 'day5' },
    { name: 'Note Importante', id: 'importantNote' },
    { name: 'Infos Rabat', id: 'rabatInfo' },
    { name: 'Infos Meknès', id: 'meknesInfo' },
    { name: 'Infos Fès', id: 'fesInfo' },
    { name: 'Lieux Insolites & Nature', id: 'trajetsInsolitesNature' },
    { name: 'Expériences Hammam', id: 'hammamsInfo' },
    { name: 'Marchés & Souks', id: 'marchesSouksInfo' },
    { name: 'Idées Cadeaux', id: 'suggestionsCadeaux' },
  ];

  const arabicPages = [
    { name: 'الرئيسية', id: 'introductionAr' },
    { name: 'اليوم الأول: الرباط وسلا', id: 'day1Ar' },
    { name: 'اليوم الثاني: وليلي ومولاي إدريس', id: 'day2Ar' },
    { name: 'اليوم الثالث: مكناس', id: 'day3Ar' },
    { name: 'اليوم الرابع: فاس (الجزء الأول)', id: 'day4Ar' },
    { name: 'اليوم الخامس: فاس (الجزء الثاني) والعودة', id: 'day5Ar' },
    { name: 'ملاحظة هامة', id: 'importantNoteAr' },
    { name: 'معلومات عن الرباط', id: 'rabatInfoAr' },
    { name: 'معلومات عن مكناس', id: 'meknesInfoAr' },
    { name: 'معلومات عن فاس', id: 'fesInfoAr' },
    { name: 'أماكن غير مألوفة وطبيعية', id: 'trajetsInsolitesNatureAr' },
    { name: 'تجارب الحمام', id: 'hammamsInfoAr' },
    { name: 'الأسواق التقليدية', id: 'marchesSouksInfoAr' },
    { name: 'أفكار هدايا', id: 'suggestionsCadeauxAr' },
  ];

  const pages = currentLanguage === 'ar' ? arabicPages : frenchPages;

  return (
    <nav className="bg-gray-800 text-white p-4 sticky top-0 z-50">
      <div className="container mx-auto flex justify-between items-center">
        <div className="text-xl font-bold">
          {currentLanguage === 'ar' ? 'مرشدك السياحي في المغرب' : 'Votre Guide au Maroc'}
        </div>
        <div className="flex items-center">
          <Menu as="div" className="relative inline-block text-left mr-4">
            <div>
              <Menu.Button className="inline-flex w-full justify-center rounded-md bg-gray-700 px-4 py-2 text-sm font-medium text-white hover:bg-gray-600 focus:outline-none focus-visible:ring-2 focus-visible:ring-white focus-visible:ring-opacity-75">
                {currentLanguage === 'ar' ? 'الصفحات' : 'Pages'}
                <ChevronDownIcon
                  className="ml-2 -mr-1 h-5 w-5 text-violet-200 hover:text-violet-100"
                  aria-hidden="true"
                />
              </Menu.Button>
            </div>
            <Transition
              as={React.Fragment}
              enter="transition ease-out duration-100"
              enterFrom="transform opacity-0 scale-95"
              enterTo="transform opacity-100 scale-100"
              leave="transition ease-in duration-75"
              leaveFrom="transform opacity-100 scale-100"
              leaveTo="transform opacity-0 scale-95"
            >
              <Menu.Items className="absolute right-0 mt-2 w-56 origin-top-right divide-y divide-gray-100 rounded-md bg-white shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none h-64 overflow-y-auto">
                <div className="px-1 py-1 ">
                  {pages.map((page) => (
                    <Menu.Item key={page.id}>
                      {({ active }) => (
                        <button
                          onClick={() => setPage(page.id)}
                          className={`${active ? 'bg-violet-500 text-white' : 'text-gray-900'
                            } group flex w-full items-center rounded-md px-2 py-2 text-sm ${currentLanguage === 'ar' ? 'text-right' : 'text-left'}`}
                        >
                          {page.name}
                        </button>
                      )}
                    </Menu.Item>
                  ))}
                </div>
              </Menu.Items>
            </Transition>
          </Menu>

          <button 
            onClick={() => setLanguage(currentLanguage === 'fr' ? 'ar' : 'fr')}
            className="p-2 rounded-md hover:bg-gray-700 focus:outline-none focus-visible:ring-2 focus-visible:ring-white focus-visible:ring-opacity-75"
          >
            <GlobeAltIcon className="h-6 w-6" />
          </button>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;

