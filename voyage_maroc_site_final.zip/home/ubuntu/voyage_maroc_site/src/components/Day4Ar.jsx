import React from 'react';

const Day4Ar = () => {
  return (
    <section id="day4-ar" className="py-8" dir="rtl">
      <h3 className="text-2xl font-bold mb-3">اليوم الرابع: نزهة في الطبيعة واكتشافات أصيلة بين الرباط ومكناس</h3>
      <div className="space-y-4">
        <div>
          <h4 className="text-xl font-semibold">الصباح:</h4>
          <p className="text-gray-700 leading-relaxed">
            ليوم يركز أكثر على الطبيعة والاكتشافات المحلية، ابدأوا بزيارة <strong>الحدائق العجيبة ببوقنادل</strong> (الواقعة بين الرباط والقنيطرة)، وهي واحة سلام تقدم تنوعاً لا يصدق من النباتات من جميع أنحاء العالم.
            <br />
            ثم واصلوا إلى <strong>الخميسات</strong> (حوالي ساعة واحدة بالسيارة من الحدائق). تشتهر هذه المدينة بسوقها الأسبوعي الكبير (عادة يوم الثلاثاء، يجب التحقق) وحرفها اليدوية البربرية، وخاصة السجاد. إنها فرصة لاكتشاف أجواء محلية أكثر وأقل سياحية.
          </p>
        </div>
        <div>
          <h4 className="text-xl font-semibold">الغداء:</h4>
          <p className="text-gray-700 leading-relaxed">
            اقتراح حر في الخميسات أو خططوا لنزهة.
          </p>
        </div>
        <div>
          <h4 className="text-xl font-semibold">بعد الظهر:</h4>
          <p className="text-gray-700 leading-relaxed">
            استكشفوا جزءاً من <strong>غابة المعمورة</strong>، أكبر غابة بلوط الفلين في المغرب. يمكنكم القيام برحلة قصيرة هناك أو ببساطة الاستمتاع بهدوء الطبيعة.
          </p>
        </div>
        <div>
          <h4 className="text-xl font-semibold">آخر المساء:</h4>
          <p className="text-gray-700 leading-relaxed">
            عودة هادئة إلى الرباط.
          </p>
        </div>
      </div>
    </section>
  );
};

export default Day4Ar;

