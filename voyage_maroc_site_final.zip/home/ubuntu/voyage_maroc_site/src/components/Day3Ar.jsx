import React from 'react';

const Day3Ar = () => {
  return (
    <section id="day3-ar" className="py-8" dir="rtl">
      <h3 className="text-2xl font-bold mb-3">اليوم الثالث: فاس، الانغماس في الروح الروحانية والحرفية للمغرب</h3>
      <div className="space-y-4">
        <div>
          <h4 className="text-xl font-semibold">الصباح:</h4>
          <p className="text-gray-700 leading-relaxed">
            الانطلاق صباحاً إلى <strong>فاس</strong> (المسافة تستغرق حوالي ساعتين ونصف إلى ثلاث ساعات). استعدوا للانغماس الكامل في <strong>فاس البالي</strong>، المدينة القديمة التاريخية، وهي متاهة رائعة مصنفة ضمن التراث العالمي لليونسكو. قوموا بزيارة إحدى المدارس القرآنية القديمة، <strong>مدرسة البوعنانية</strong> أو <strong>مدرسة العطارين</strong>، المشهورتين بهندستهما المعمارية الراقية. يمكنكم أيضاً الاستمتاع بمنظر <strong>جامعة القرويين</strong> الشهيرة من الخارج، وهي أقدم جامعة في العالم لا تزال تعمل.
          </p>
        </div>
        <div>
          <h4 className="text-xl font-semibold">الغداء:</h4>
          <p className="text-gray-700 leading-relaxed">
            اقتراح حر في مطعم تقليدي في قلب المدينة القديمة لتذوق الأطباق الفاسية.
          </p>
        </div>
        <div>
          <h4 className="text-xl font-semibold">بعد الظهر:</h4>
          <p className="text-gray-700 leading-relaxed">
            اكتشفوا <strong>مدابغ شعوارة</strong> الشهيرة (عادة ما يكون الوصول إلى الشرفات البانورامية مدفوعاً ولكنه يوفر إطلالة فريدة على عملية معالجة الجلود). قوموا بزيارة <strong>ساحة النجارين</strong> بنافورتها الجميلة و<strong>متحف الفنون والحرف الخشبية</strong>. تيهوا في الأسواق الملونة والنابضة بالحياة، حيث ستجدون حرفاً يدوية غنية ومتنوعة.
          </p>
        </div>
        <div>
          <h4 className="text-xl font-semibold">آخر المساء:</h4>
          <p className="text-gray-700 leading-relaxed">
            العودة إلى الرباط (المسافة تستغرق حوالي ساعتين ونصف إلى ثلاث ساعات).
          </p>
        </div>
      </div>
    </section>
  );
};

export default Day3Ar;

