import React from 'react';

const RabatInfo = () => {
  return (
    <section id="rabat-info" className="py-8 bg-gray-50">
      <div className="container mx-auto px-4">
        <h3 className="text-2xl font-bold mb-3">Rabat - Sites Historiques et Naturels</h3>
        <h4 className="text-xl font-semibold mb-2">Monuments et Lieux d'Intérêt à Rabat</h4>
        <p className="text-gray-700 leading-relaxed mb-4">
          Rabat, capitale du Maroc, regorge de sites historiques et culturels, dont plusieurs sont classés au patrimoine mondial de l'UNESCO. Voici quelques incontournables :
        </p>
        <ul className="list-disc list-inside space-y-2 mb-4">
          <li><strong>Kasbah des Oudayas :</strong> Une ancienne forteresse avec des ruelles pittoresques, des maisons bleues et blanches, et une vue imprenable sur l'océan et l'embouchure du Bouregreg.</li>
          <li><strong>Tour Hassan :</strong> Minaret inachevé d’une mosquée grandiose projetée à la fin du XIIe siècle. C’est un symbole emblématique de Rabat.</li>
          <li><strong>Mausolée de Mohammed V :</strong> Chef-d’œuvre de l’architecture marocaine moderne, abritant les tombes du roi Mohammed V et de ses fils.</li>
          <li><strong>Chellah :</strong> Nécropole mérinide construite sur les vestiges d’une ancienne cité romaine (Sala Colonia). Le site combine ruines romaines, vestiges islamiques et jardins luxuriants peuplés de cigognes.</li>
          <li><strong>Médina de Rabat :</strong> Le cœur historique de la ville, avec ses souks animés, ses artisans et son ambiance traditionnelle.</li>
          <li><strong>Palais Royal (Dar El Makhzen) :</strong> Résidence officielle du roi du Maroc. Bien que l’intérieur ne soit pas accessible au public, l’extérieur et ses vastes esplanades sont impressionnants.</li>
          <li><strong>Bab El Had et Bab Rouah :</strong> Portes monumentales historiques de la ville.</li>
          <li><strong>Ville Nouvelle :</strong> Construite sous le protectorat français, elle présente une architecture Art déco et des avenues bordées d’arbres.</li>
          <li><strong>Jardins Exotiques de Bouknadel (proximité) :</strong> Un magnifique jardin botanique situé à quelques kilomètres de Rabat, offrant une grande diversité de plantes du monde entier.</li>
          <li><strong>Forêt de la Maâmora (proximité) :</strong> La plus grande forêt de chênes-lièges du Maroc, offrant des possibilités de randonnées et de détente en nature.</li>
        </ul>
        <p className="text-sm text-gray-600">
          Sources principales : Visit Rabat, UNESCO, TripAdvisor
        </p>
      </div>
    </section>
  );
};

export default RabatInfo;

