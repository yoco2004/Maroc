import React from 'react';

const MeknesInfo = () => {
  return (
    <section id="meknes-info" className="py-8 bg-gray-50">
      <div className="container mx-auto px-4">
        <h3 className="text-2xl font-bold mb-3">Meknès - Sites Historiques, Naturels et Insolites</h3>
        
        <div className="mb-6">
          <h4 className="text-xl font-semibold mb-2">Ville historique de Meknès (UNESCO)</h4>
          <p className="text-gray-700 leading-relaxed">
            Fondée au XIe siècle par les Almoravides, Meknès devint capitale sous Moulay Ismaïl (1672-1727). Il en fit une impressionnante cité de style hispano-mauresque, ceinte de hautes murailles et de portes monumentales. Elle témoigne de l'alliance des styles islamique et européen au XVIIe siècle.
          </p>
          <p className="text-gray-700 leading-relaxed mt-2">
            La ville historique comprend la médina et la ville impériale, avec des monuments clés comme des mosquées, hammams, palais, greniers, et des remparts gigantesques atteignant 15m de hauteur. Elle illustre l'architecture de terre (pisé) des villes sub-sahariennes du Maghreb.
          </p>
          <p className="text-sm text-gray-600 mt-1">Source: UNESCO World Heritage Centre</p>
        </div>

        <div className="mb-6">
          <h4 className="text-xl font-semibold mb-2">Lieux Insolites à Meknès</h4>
          <h5 className="text-lg font-semibold mb-1">Habs Kara, l’ancienne prison souterraine</h5>
          <p className="text-gray-700 leading-relaxed">
            Un véritable labyrinthe sous la ville, dans l'enceinte de la kasbah ismaélienne. Selon la légende, un prisonnier portugais, Kara, l'aurait construite pour racheter sa liberté, créant un espace capable de contenir plus de 40 000 prisonniers et s'étendant sur des kilomètres. Aussi appelée "prison des chrétiens", elle servait à enfermer les prisonniers de guerre. On y accède par un petit escalier menant à un monde souterrain obscur.
          </p>
          <p className="text-sm text-gray-600 mt-1">Source: Le360.ma</p>
        </div>

        <div>
          <h4 className="text-xl font-semibold mb-2">Nature aux Alentours de Meknès</h4>
          <p className="text-gray-700 leading-relaxed mb-2">
            Au-delà de ses remparts, Meknès offre un arrière-pays riche en espaces naturels, notamment la plaine du Saïss s'ouvrant sur le Moyen Atlas.
          </p>
          <ul className="list-disc list-inside space-y-1">
            <li><strong>Montagnes du Moyen Atlas :</strong> Cèdres majestueux, sources de rivières formant lacs et sources.</li>
            <li><strong>Sources d’Oulmès et de Vittel :</strong> Réputées pour leurs qualités revigorantes.</li>
            <li><strong>Grotte du Lion à El Hajeb :</strong> Curiosité naturelle avec vue panoramique sur la plaine du Saïss.</li>
            <li><strong>Lacs de montagne :</strong> Eaux pures et fraîches, propices à la détente ou la pêche.</li>
            <li><strong>Plaine du Saïss :</strong> Vaste plaine fertile offrant des paysages ouverts.</li>
          </ul>
          <p className="text-gray-700 leading-relaxed mt-2">
            Ces sites peuvent être explorés à pied, à vélo ou à cheval.
          </p>
          <p className="text-sm text-gray-600 mt-1">Source: Office National Marocain du Tourisme</p>
        </div>

      </div>
    </section>
  );
};

export default MeknesInfo;

