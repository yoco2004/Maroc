import React from 'react';

const HammamsInfo = () => {
  return (
    <div className="p-6 bg-white shadow-lg rounded-lg">
      <h2 className="text-3xl font-bold mb-6 text-center text-green-700">Expériences Hammam Authentiques</h2>

      <div className="mb-8">
        <h3 className="text-2xl font-semibold mb-3 text-green-600">Hammams à Rabat</h3>
        <div className="mb-4 p-4 border-l-4 border-green-500 bg-green-50">
          <h4 className="text-xl font-semibold mb-2">Hammam du Salon Ritania</h4>
          <p><strong className="font-semibold">Adresse :</strong> Avenue Al Alaouyine 22, appartement n°2, quartier Hassan, Rabat.</p>
          <p><strong className="font-semibold">Description (basée sur un avis de 2016) :</strong> Semble être un salon proposant des services de hammam plutôt qu'un hammam public traditionnel. L'avis mentionne une expérience agréable avec gommage au savon noir, kessa, lavage des cheveux, enveloppement au rhassoul et massage. Utilisation d'un pommeau de douche plutôt que de seaux traditionnels.</p>
          <p><strong className="font-semibold">Source :</strong> Forum Routard</p>
          <p><strong className="font-semibold">Note :</strong> L'avis date de 2016, il faudrait vérifier si l'établissement existe toujours et si les services/prix sont similaires.</p>
        </div>
        <div className="p-4 border-l-4 border-green-500 bg-green-50">
          <h4 className="text-xl font-semibold mb-2">Hammams Locaux à Rabat (Médina et environs)</h4>
          <p>Plusieurs hammams locaux sont mentionnés dans le blog "Away With The Steiners", offrant une expérience plus traditionnelle et abordable que les spas privés. Les prix d'entrée varient généralement entre 15 et 25 Dhs, avec des coûts supplémentaires pour le gommage (50-150 Dhs) ou des forfaits incluant les produits.</p>
          <p className="mt-2"><strong className="font-semibold">Dans la Médina de Rabat :</strong></p>
          <ul className="list-disc list-inside ml-4">
            <li>Laalou Hammam</li>
            <li>Chourafaa Hammam (Entrée: 13 Dhs, Forfait: 200 Dhs)</li>
            <li>Buiba Hammam</li>
            <li>Al-Attarin Hammam (Entrée: 15 Dhs, Gommage: 60 Dhs, Massage et gommage: 120 Dhs)</li>
          </ul>
          <p className="mt-2"><strong className="font-semibold">Hors Médina de Rabat :</strong></p>
          <ul className="list-disc list-inside ml-4">
            <li>Marassa Hammam (Entrée: 23 Dhs, Gommage: 70 Dhs, Forfait: 150 Dhs)</li>
            <li>Tkatek Hammam (Entrée: 15 Dhs, Gommage: 50 Dhs, Forfait: 150 Dhs)</li>
          </ul>
          <p className="mt-2"><strong className="font-semibold">Conseils généraux pour les hammams locaux :</strong></p>
          <ul className="list-disc list-inside ml-4">
            <li><strong className="font-semibold">À apporter :</strong> Vêtements de rechange, sous-vêtements, articles de toilette, serviette.</li>
            <li><strong className="font-semibold">Articles disponibles à l'achat :</strong> Gant exfoliant (kess) ~10 Dhs, savon noir (savon beldi) ~2 Dhs, shampoing.</li>
            <li><strong className="font-semibold">Pourboire :</strong> 10-20% à la personne qui s'occupe de vous.</li>
            <li><strong className="font-semibold">Tenue :</strong> Femmes en sous-vêtements (culotte). Hommes en sous-vêtements ou caleçons.</li>
          </ul>
          <p className="mt-2"><strong className="font-semibold">Source :</strong> Away With The Steiners</p>
          <p><strong className="font-semibold">Note :</strong> Prix et informations d'avril 2025 (selon l'article). Vérifier sur place.</p>
        </div>
      </div>

      <div className="mb-8">
        <h3 className="text-2xl font-semibold mb-3 text-green-600">Hammams à Meknès</h3>
        <p className="mb-2 italic">La recherche d'informations spécifiques et récentes sur les hammams traditionnels et abordables à Meknès est en cours. Les sources comme TripAdvisor sont parfois difficiles d’accès et les blogs de voyage ne listent pas toujours des adresses précises.</p>
        <div className="p-4 border-l-4 border-green-500 bg-green-50">
          <h4 className="text-xl font-semibold mb-2">Pistes de recherche et informations générales :</h4>
          <ul className="list-disc list-inside ml-4">
            <li><strong className="font-semibold">AquaSpa (Meknès) :</strong> Mentionné sur TripAdvisor. Avis ancien (100 Dhs pour hammam marocain). Vérifier avis récents.</li>
            <li><strong className="font-semibold">Buddha Hammam Meknès :</strong> Site web existant. Rituels tradition/modernité. Vérifier tarifs et avis.</li>
            <li><strong className="font-semibold">Bain Turc Meknès (Facebook) :</strong> Page Facebook. Chercher avis, prix, type d'expérience.</li>
            <li><strong className="font-semibold">Recherches locales / Demander sur place :</strong> Stratégie recommandée pour trouver des adresses authentiques et abordables non référencées en ligne.</li>
          </ul>
          <p className="mt-2"><strong className="font-semibold">Note :</strong> Vérifier la fraîcheur des informations et des avis.</p>
        </div>
      </div>

      <div>
        <h3 className="text-2xl font-semibold mb-3 text-green-600">Hammams à Fès</h3>
        <p className="mb-2 italic">L'accès à certaines plateformes d’avis peut être limité, mais des blogs de voyage et des recommandations locales peuvent fournir des pistes.</p>
        <div className="p-4 border-l-4 border-green-500 bg-green-50">
          <h4 className="text-xl font-semibold mb-2">Pistes de recherche et informations générales :</h4>
          <ul className="list-disc list-inside ml-4">
            <li><strong className="font-semibold">Hammam Mernissi & Spa (Fès) :</strong> Mentionné sur TripAdvisor. Avis partagés. Consulter avis récents.</li>
            <li><strong className="font-semibold">Expérience Hammam dans la Médina (Blog "moicestclo.fr") :</strong> Article de 2019 mentionne hammam + massage pour 450 Dhs. Nom non précisé.</li>
            <li><strong className="font-semibold">Hammam beldi du quartier Moulay Idriss (Recommandé par Riad Jamaï) :</strong> Information de 2018. Pas de détails sur nom/prix.</li>
            <li><strong className="font-semibold">Yuba Cyn Spa Hammam Massage Fes (Facebook) :</strong> Page Facebook avec avis positifs sur massages. Vérifier hammam traditionnel et tarifs.</li>
            <li><strong className="font-semibold">Recherches locales / Demander sur place :</strong> Excellente approche pour Fès également.</li>
          </ul>
          <p className="mt-2"><strong className="font-semibold">Note générale :</strong> Mélange d'options à Fès (spas touristiques, hammams locaux). Vérifier avis récents, prix, et type d'expérience.</p>
        </div>
      </div>

    </div>
  );
};

export default HammamsInfo;

