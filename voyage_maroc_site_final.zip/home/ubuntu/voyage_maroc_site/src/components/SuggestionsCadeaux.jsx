import React from 'react';

const SuggestionsCadeaux = () => {
  return (
    <div className="p-6 bg-white shadow-lg rounded-lg">
      <h2 className="text-3xl font-bold mb-6 text-center text-purple-700">Idées Cadeaux Typiquement Marocains pour la Famille</h2>
      <p className="mb-4 text-lg text-gray-700">Le Maroc regorge de trésors artisanaux et de produits locaux qui feront des cadeaux uniques et mémorables. Explorez les souks animés de Rabat, Meknès et Fès pour gâter votre épouse et vos enfants.</p>

      <div className="mb-8">
        <h3 className="text-2xl font-semibold mb-3 text-purple-600">Pour Madame : Élégance et Bien-être</h3>
        <div className="space-y-3 text-gray-600">
          <p>Pensez à l'élégance d'un <strong>caftan</strong> ou d'une <strong>djellaba</strong> en soie ou coton finement brodé (Souk Lakbir à Rabat, Souk Sebat à Meknès/Fès).</p>
          <p>Les <strong>bijoux berbères en argent</strong> (Kissaria de Rabat, souks de Fès) ornés de pierres semi-précieuses sont un choix magnifique.</p>
          <p>Pour le bien-être, optez pour des <strong>produits cosmétiques naturels</strong> : <strong>huile d'argan</strong>, <strong>savon noir</strong>, <strong>ghassoul</strong>, eaux florales, khôl (Souk El-Attarine à Rabat, souks aux épices de Fès).</p>
          <p>Un <strong>sac en cuir</strong> artisanal, des <strong>babouches</strong> colorées (Souk Aïn Allou à Fès), une belle <strong>poterie de Fès</strong> (céramique bleue), ou des objets en <strong>cuivre ciselé</strong> (Souk des Chaudronniers à Fès) sont également d'excellents choix.</p>
        </div>
      </div>

      <div className="mb-8">
        <h3 className="text-2xl font-semibold mb-3 text-purple-600">Pour les Enfants : Artisanat Ludique et Souvenirs Enchantés</h3>
        <div className="space-y-3 text-gray-600">
          <p>Les <strong>jouets en bois</strong> fabriqués localement (petites voitures, animaux, instruments miniatures) sont une excellente option (Souk Nejjarine à Fès/Meknès).</p>
          <p>De <strong>petites babouches</strong> en cuir coloré adaptées à leur taille feront leur bonheur.</p>
          <p>Les <strong>instruments de musique traditionnels</strong> comme les derboukas ou les qraqeb (souk près de Bab el Jdid à Meknès) sont amusants et initiatiques.</p>
          <p>Pour les petites filles, de jolies <strong>poupées en costumes traditionnels</strong> ou des petits <strong>bijoux fantaisie</strong>.</p>
          <p>Les <strong>coffrets en bois décorés</strong> (thuya, citronnier) du Souk Nejjarine peuvent servir de boîtes à trésors.</p>
          <p>N'oubliez pas les <strong>gourmandises</strong> : pâtisseries marocaines, nougat (Souk Chemainne à Fès).</p>
          <p>Un petit <strong>tapis berbère</strong> coloré pour leur chambre peut être un cadeau original et durable.</p>
        </div>
      </div>

      <div>
        <h3 className="text-2xl font-semibold mb-3 text-purple-600">Conseils pour vos Achats :</h3>
        <ul className="list-disc list-inside space-y-2 text-gray-600 ml-4">
          <li><strong>Négociez avec le sourire :</strong> Cela fait partie de l'expérience des souks.</li>
          <li><strong>Prenez votre temps :</strong> Flânez, comparez les prix et la qualité.</li>
          <li><strong>Privilégiez l'artisanat local :</strong> Cherchez les ateliers où les artisans travaillent.</li>
          <li><strong>Vérifiez la qualité :</strong> Examinez attentivement les articles (cuir, coutures, finesse des bijoux).</li>
        </ul>
        <p className="mt-4 text-lg text-gray-700">En choisissant des cadeaux dans les souks, vous soutenez l'artisanat local et offrez à votre famille des souvenirs authentiques et chargés de l'âme du Maroc.</p>
      </div>

    </div>
  );
};

export default SuggestionsCadeaux;

