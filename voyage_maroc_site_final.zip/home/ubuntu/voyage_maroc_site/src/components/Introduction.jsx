import React from 'react';

const Introduction = () => {
  return (
    <section id="introduction" className="py-8">
      <h2 className="text-3xl font-bold mb-4 text-center">Introduction</h2>
      <p className="text-lg text-gray-700 leading-relaxed">
        Bienvenue au Maroc ! Cet itinéraire de 5 jours a été conçu pour vous offrir un bel aperçu des richesses historiques, naturelles et culturelles du pays, en rayonnant chaque jour depuis votre hébergement à Rabat. Vous explorerez la capitale, les cités impériales de Meknès et Fès, tout en découvrant des paysages variés et quelques pépites moins connues.
      </p>
    </section>
  );
};

export default Introduction;

