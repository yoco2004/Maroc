import React from 'react';

const ImportantNote = () => {
  return (
    <section id="important-note" className="py-8 bg-yellow-100 border-t border-b border-yellow-300">
      <div className="container mx-auto px-4">
        <h3 className="text-2xl font-bold mb-3 text-yellow-700">Note Importante</h3>
        <p className="text-gray-700 leading-relaxed">
          Cet itinéraire est une suggestion et peut être adapté selon vos intérêts et votre rythme. Les temps de trajet sont indicatifs et peuvent varier en fonction de la circulation. La location d’une voiture avec chauffeur ou la vôtre vous offrira le plus de flexibilité pour ce type de circuit avec des retours quotidiens.
        </p>
        <p className="text-gray-700 leading-relaxed mt-2">
          Nous vous souhaitons un excellent voyage au Maroc !
        </p>
      </div>
    </section>
  );
};

export default ImportantNote;

