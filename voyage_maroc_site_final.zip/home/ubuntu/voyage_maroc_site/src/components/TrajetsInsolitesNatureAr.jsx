import React from 'react';

const TrajetsInsolitesNatureAr = () => {
  const trajets = [
    {
      title: "وليلي (بالقرب من مكناس)",
      description: "موقع أثري روماني، يضم بقايا مدينة قديمة، معبد جوبيتر، حمامات، وفسيفساء محفوظة جيدًا.",
      pertinence: "موقع تاريخي لا بد منه، تم تحديده بالفعل عند جمع المعلومات عن مكناس، ولكن يجب وضعه بشكل جيد في خط سير الرحلة."
    },
    {
      title: "مغارة فريواطو (منطقة تازة)",
      description: "المغارة الوحيدة المجهزة في المغرب، ذات حجم استثنائي (عرض 20 مترًا، عمق 150 مترًا). يمكن الوصول إليها عن طريق درج على طول الجدار، مع هوابط وصواعد.",
      pertinence: "مكان طبيعي وغير مألوف، يجب تقييمه بناءً على المسافة والوقت المتاح في رحلة إلى فاس أو منها."
    },
    {
      title: "بحيرة أكلمام أزكزا (منطقة خنيفرة)",
      description: "بحيرة تقع في بيئة طبيعية من الجبال والغابات، مناسبة للمشي لمسافات طويلة.",
      pertinence: "موقع طبيعي مثير للاهتمام، يجب أخذه في الاعتبار للقيام برحلة طبيعية إذا سمح خط سير الرحلة بذلك."
    },
    {
      title: "إفران والمناطق المحيطة بها (الأطلس المتوسط)",
      description: "مدينة جبلية تلقب بـ \"سويسرا المغرب الصغيرة\" لهندستها المعمارية ومناخها. بالقرب من منتزه إفران الوطني بغابات الأرز (أرز غورو)، قرود المكاك البربري، والبحيرات (ضاية عوا).",
      pertinence: "طبيعة وتغيير في الأجواء، يمكن أن تشكل رحلة ليوم واحد أو محطة في رحلة أطول."
    },
    {
      title: "مولاي إدريس زرهون (بالقرب من مكناس ووليلي)",
      description: "مدينة مقدسة تقع على تلة، تضم ضريح إدريس الأول. مدينة خلابة ذات إطلالات بانورامية.",
      pertinence: "موقع تاريخي وثقافي رئيسي، غالبًا ما تتم زيارته مع وليلي."
    },
    {
      title: "غابة المعمورة (بين الرباط والقنيطرة)",
      description: "غابة كبيرة من بلوط الفلين. يمكن أن توفر استراحة في الطبيعة.",
      pertinence: "طبيعة، يسهل الوصول إليها على الطريق."
    },
    {
      title: "مدينة الخميسات (على الطريق بين الرباط ومكناس)",
      description: "مدينة تشتهر بسوقها الأسبوعي وحرفها اليدوية البربرية (خاصة السجاد). أقل سياحية، ويمكن أن تقدم تجربة أكثر أصالة.",
      pertinence: "ثقافة محلية وأصالة."
    },
    {
      title: "مدينة صفرو (بالقرب من فاس)",
      description: "مدينة قديمة بها مدينة قديمة وشلالات (شلال واد أغاي) وثقافة يهودية تاريخية. تشتهر بمهرجان الكرز.",
      pertinence: "طبيعة وثقافة، بالقرب من فاس."
    }
  ];

  return (
    <section id="trajets-insolites-nature-ar" className="py-8 bg-green-50" dir="rtl">
      <div className="container mx-auto px-4">
        <h3 className="text-2xl font-bold mb-4 text-center">أماكن غير مألوفة وطبيعية على طول الطرق</h3>
        <p className="text-gray-600 text-sm mb-4 text-center">معلومات مستخرجة من \"المغرب غير المألوف: 17 مكانًا (مختلفًا تمامًا) للزيارة!\" وبحوث أخرى.</p>
        <div className="grid md:grid-cols-2 gap-6">
          {trajets.map((item, index) => (
            <div key={index} className="bg-white p-6 rounded-lg shadow-md">
              <h4 className="text-xl font-semibold mb-2 text-green-700">{item.title}</h4>
              <p className="text-gray-700 leading-relaxed mb-1"><strong className="font-medium">الوصف:</strong> {item.description}</p>
              <p className="text-gray-700 leading-relaxed"><strong className="font-medium">الأهمية:</strong> {item.pertinence}</p>
            </div>
          ))}
        </div>
        <p className="text-sm text-gray-600 mt-4 text-center">سيتعين التحقق من الموقع الدقيق وإمكانية دمج هذه الأماكن في رحلات يومية مع العودة إلى الرباط.</p>
      </div>
    </section>
  );
};

export default TrajetsInsolitesNatureAr;

