import React from 'react';

const ImportantNoteAr = () => {
  return (
    <section id="important-note-ar" className="py-8 bg-yellow-100 border-t border-b border-yellow-300" dir="rtl">
      <div className="container mx-auto px-4">
        <h3 className="text-2xl font-bold mb-3 text-yellow-700">ملاحظة هامة</h3>
        <p className="text-gray-700 leading-relaxed">
          هذا البرنامج هو مجرد اقتراح ويمكن تكييفه وفقًا لاهتماماتكم ووتيرتكم. أوقات الرحلات هي تقديرية وقد تختلف بناءً على حركة المرور. إن استئجار سيارة مع سائق أو سيارتكم الخاصة سيوفر لكم أكبر قدر من المرونة لهذا النوع من الجولات مع العودة اليومية.
        </p>
        <p className="text-gray-700 leading-relaxed mt-2">
          نتمنى لكم رحلة ممتازة في المغرب!
        </p>
      </div>
    </section>
  );
};

export default ImportantNoteAr;

