import React from 'react';

const Day5Ar = () => {
  return (
    <section id="day5-ar" className="py-8" dir="rtl">
      <h3 className="text-2xl font-bold mb-3">اليوم الخامس: سلا، المدينة التوأم، وانطباعات أخيرة عن الرباط</h3>
      <div className="space-y-4">
        <div>
          <h4 className="text-xl font-semibold">الصباح:</h4>
          <p className="text-gray-700 leading-relaxed">
            اعبروا نهر أبي رقراق لاكتشاف <strong>سلا</strong>، المدينة المجاورة للرباط. استكشفوا <strong>مدينتها القديمة</strong>، الأكثر هدوءًا وأصالة من مدينة الرباط. قوموا بزيارة <strong>مدرستها المرينية</strong> الرائعة واستمتعوا بمنظر <strong>مسجدها الكبير</strong> من الخارج.
          </p>
        </div>
        <div>
          <h4 className="text-xl font-semibold">الغداء:</h4>
          <p className="text-gray-700 leading-relaxed">
            اقتراح حر في سلا أو عند العودة إلى الرباط.
          </p>
        </div>
        <div>
          <h4 className="text-xl font-semibold">بعد الظهر:</h4>
          <p className="text-gray-700 leading-relaxed">
            استفيدوا من آخر فترة بعد الظهر في الرباط للقيام بأنشطة حسب رغبتكم: تعميق زيارة موقع أعجبكم بشكل خاص، القيام ببعض التسوق التذكاري في المدينة القديمة، زيارة متحف مثل <strong>متحف محمد السادس للفن الحديث والمعاصر</strong> أو <strong>متحف التاريخ والحضارات</strong>، أو ببساطة الاسترخاء في مقهى.
          </p>
        </div>
        <div>
          <h4 className="text-xl font-semibold">المساء:</h4>
          <p className="text-gray-700 leading-relaxed">
            عشاء أخير في الرباط، مع استعادة ذكريات اكتشافات رحلتكم.
          </p>
        </div>
      </div>
    </section>
  );
};

export default Day5Ar;

