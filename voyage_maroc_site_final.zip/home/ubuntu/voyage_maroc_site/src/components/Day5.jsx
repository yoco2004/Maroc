import React from 'react';

const Day5 = () => {
  return (
    <section id="day5" className="py-8">
      <h3 className="text-2xl font-bold mb-3">Jour 5 : Salé, la Ville Jumelle, et Dernières Impressions de Rabat</h3>
      <div className="space-y-4">
        <div>
          <h4 className="text-xl font-semibold">Matin :</h4>
          <p className="text-gray-700 leading-relaxed">
            Traversez le fleuve Bouregreg pour découvrir <strong>Salé</strong>, la ville voisine de Rabat. Explorez sa <strong>Médina</strong>, plus paisible et authentique que celle de Rabat. Visitez sa magnifique <strong>Medersa mérinide</strong> et admirez l'extérieur de sa <strong>Grande Mosquée</strong>.
          </p>
        </div>
        <div>
          <h4 className="text-xl font-semibold">Déjeuner :</h4>
          <p className="text-gray-700 leading-relaxed">
            Suggestion libre à Salé ou de retour à Rabat.
          </p>
        </div>
        <div>
          <h4 className="text-xl font-semibold">Après-midi :</h4>
          <p className="text-gray-700 leading-relaxed">
            Profitez de votre dernière après-midi à Rabat pour des activités selon vos envies : approfondir la visite d'un site que vous avez particulièrement apprécié, faire quelques achats de souvenirs dans la médina, visiter un musée comme le <strong>Musée Mohammed VI d'art moderne et contemporain</strong> ou le <strong>Musée de l'Histoire et des Civilisations</strong>, ou simplement vous détendre dans un café.
          </p>
        </div>
        <div>
          <h4 className="text-xl font-semibold">Soir :</h4>
          <p className="text-gray-700 leading-relaxed">
            Dernier dîner à Rabat, en repensant aux découvertes de votre séjour.
          </p>
        </div>
      </div>
    </section>
  );
};

export default Day5;

