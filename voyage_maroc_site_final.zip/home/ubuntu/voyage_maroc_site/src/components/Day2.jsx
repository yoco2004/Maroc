import React from 'react';

const Day2 = () => {
  return (
    <section id="day2" className="py-8">
      <h3 className="text-2xl font-bold mb-3">Jour 2 : Meknès, la Grandeur Impériale, et les Vestiges Romains de Volubilis</h3>
      <div className="space-y-4">
        <div>
          <h4 className="text-xl font-semibold">Matin :</h4>
          <p className="text-gray-700 leading-relaxed">
            Départ matinal en direction de <strong>Volubilis</strong> (trajet d'environ 1h45 à 2h). Explorez ce site archéologique classé au patrimoine mondial de l'UNESCO, l'une des villes romaines les mieux préservées d'Afrique du Nord, avec ses mosaïques, son arc de triomphe et ses temples.
            <br />
            Continuez ensuite vers la ville sainte de <strong>Moulay Idriss Zerhoun</strong>, perchée sur une colline et offrant une vue panoramique sur la région. C'est un lieu de pèlerinage important au Maroc.
          </p>
        </div>
        <div>
          <h4 className="text-xl font-semibold">Déjeuner :</h4>
          <p className="text-gray-700 leading-relaxed">
            Suggestion libre à Moulay Idriss ou en arrivant à Meknès.
          </p>
        </div>
        <div>
          <h4 className="text-xl font-semibold">Après-midi :</h4>
          <p className="text-gray-700 leading-relaxed">
            Découverte de <strong>Meknès</strong>, la cité impériale du Sultan Moulay Ismaïl. Admirez la monumentale <strong>Bab Mansour</strong>, l'une des plus belles portes du Maroc, flânez sur la vivante <strong>Place El Hedim</strong>, et visitez le <strong>Mausolée de Moulay Ismaïl</strong>. Pour une touche d'insolite, descendez dans la mystérieuse prison souterraine de <strong>Habs Qara</strong>.
          </p>
        </div>
        <div>
          <h4 className="text-xl font-semibold">Fin d'après-midi :</h4>
          <p className="text-gray-700 leading-relaxed">
            Retour à Rabat (trajet d'environ 1h45 à 2h).
          </p>
        </div>
      </div>
    </section>
  );
};

export default Day2;

