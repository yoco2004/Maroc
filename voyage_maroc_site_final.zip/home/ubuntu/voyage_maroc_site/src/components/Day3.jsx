import React from 'react';

const Day3 = () => {
  return (
    <section id="day3" className="py-8">
      <h3 className="text-2xl font-bold mb-3">Jour 3 : Fès, Immersion dans l'Âme Spirituelle et Artisanale du Maroc</h3>
      <div className="space-y-4">
        <div>
          <h4 className="text-xl font-semibold">Matin :</h4>
          <p className="text-gray-700 leading-relaxed">
            Départ matinal pour <strong>Fès</strong> (trajet d'environ 2h30 à 3h). Préparez-vous à une immersion totale dans <strong>Fès el-Bali</strong>, la médina historique, un labyrinthe fascinant classé au patrimoine mondial de l'UNESCO. Visitez l'une des anciennes écoles coraniques, la <strong>Medersa Bou Inania</strong> ou la <strong>Medersa Attarine</strong>, réputées pour leur architecture raffinée. Vous pourrez également admirer de l'extérieur la célèbre <strong>Université Al Quaraouiyine</strong>, la plus ancienne université au monde encore en activité.
          </p>
        </div>
        <div>
          <h4 className="text-xl font-semibold">Déjeuner :</h4>
          <p className="text-gray-700 leading-relaxed">
            Suggestion libre dans un restaurant traditionnel au cœur de la médina pour déguster les spécialités fassies.
          </p>
        </div>
        <div>
          <h4 className="text-xl font-semibold">Après-midi :</h4>
          <p className="text-gray-700 leading-relaxed">
            Découvrez les célèbres <strong>tanneries Chouara</strong> (l'accès aux terrasses panoramiques est généralement payant mais offre une vue unique sur le travail des peaux). Visitez la <strong>Place Nejjarine</strong> avec sa belle fontaine et son <strong>Musée des Arts et Métiers du Bois</strong>. Perdez-vous dans les souks colorés et animés, où vous trouverez un artisanat riche et varié.
          </p>
        </div>
        <div>
          <h4 className="text-xl font-semibold">Fin d'après-midi :</h4>
          <p className="text-gray-700 leading-relaxed">
            Retour à Rabat (trajet d'environ 2h30 à 3h).
          </p>
        </div>
      </div>
    </section>
  );
};

export default Day3;

