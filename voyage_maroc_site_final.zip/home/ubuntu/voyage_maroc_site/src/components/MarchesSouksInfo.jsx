import React from 'react';

const MarchesSouksInfo = () => {
  return (
    <div className="p-6 bg-white shadow-lg rounded-lg">
      <h2 className="text-3xl font-bold mb-6 text-center text-blue-700">Exploration des Marchés et Souks Typiques</h2>

      {/* Rabat */}
      <div className="mb-8">
        <h3 className="text-2xl font-semibold mb-3 text-blue-600">Marchés et Souks à Rabat</h3>
        <p className="mb-2 italic">Informations basées sur l'article de StayHere.ma (mai 2024).</p>
        
        <div className="mb-4 p-4 border-l-4 border-blue-500 bg-blue-50">
          <h4 className="text-xl font-semibold">Marché Central Rabat</h4>
          <p><strong>Description :</strong> Ambiance de halles traditionnelles, produits frais, porte d'entrée de la Médina.</p>
          <p><strong>Idéal pour :</strong> S'imprégner de l'atmosphère, produits frais.</p>
        </div>

        <div className="mb-4 p-4 border-l-4 border-blue-500 bg-blue-50">
          <h4 className="text-xl font-semibold">Souk Lakbir</h4>
          <p><strong>Description :</strong> Diversité de tissus, robes marocaines traditionnelles. Ancien marché aux esclaves.</p>
          <p><strong>Idéal pour :</strong> Tissus, caftans, djellabas. Négocier les prix.</p>
        </div>

        <div className="mb-4 p-4 border-l-4 border-blue-500 bg-blue-50">
          <h4 className="text-xl font-semibold">Kissaria</h4>
          <p><strong>Description :</strong> Spécialisé dans les bijoux, des pièces rares aux plus abordables.</p>
          <p><strong>Idéal pour :</strong> Bijoux en argent, or, pierres semi-précieuses.</p>
        </div>

        <div className="mb-4 p-4 border-l-4 border-blue-500 bg-blue-50">
          <h4 className="text-xl font-semibold">Souk Lakhmis</h4>
          <p><strong>Description :</strong> Variété de plantes. Havre de verdure dans la médina.</p>
          <p><strong>Idéal pour :</strong> Plantes, fleurs.</p>
        </div>

        <div className="mb-4 p-4 border-l-4 border-blue-500 bg-blue-50">
          <h4 className="text-xl font-semibold">Souk El-Attarine</h4>
          <p><strong>Description :</strong> Souk aux épices, parfums bio, remèdes traditionnels.</p>
          <p><strong>Idéal pour :</strong> Épices, parfums, produits de soins naturels.</p>
        </div>

        <div className="p-4 border-l-4 border-blue-500 bg-blue-50">
          <h4 className="text-xl font-semibold">Souk Al-Ghazal</h4>
          <p><strong>Description :</strong> Commerce de laine teinte pour tapis ou vêtements. Vaste et fréquenté le week-end.</p>
          <p><strong>Idéal pour :</strong> Laine, tapis.</p>
        </div>
      </div>

      {/* Meknès */}
      <div className="mb-8">
        <h3 className="text-2xl font-semibold mb-3 text-blue-600">Marchés et Souks à Meknès</h3>
        <p className="mb-2 italic">Informations basées sur le site du Conseil Préfectoral du Tourisme de Meknès.</p>

        <div className="mb-4 p-4 border-l-4 border-blue-500 bg-blue-50">
          <h4 className="text-xl font-semibold">Souk Lahdim</h4>
          <p><strong>Description :</strong> Réputé pour les olives. Goûter avant de choisir.</p>
          <p><strong>Idéal pour :</strong> Olives, produits du terroir.</p>
        </div>

        <div className="mb-4 p-4 border-l-4 border-blue-500 bg-blue-50">
          <h4 className="text-xl font-semibold">Souk Sekkakine</h4>
          <p><strong>Description :</strong> Couteaux, objets en fer blanc, théières.</p>
          <p><strong>Idéal pour :</strong> Artisanat métallique, ustensiles traditionnels.</p>
        </div>

        <div className="mb-4 p-4 border-l-4 border-blue-500 bg-blue-50">
          <h4 className="text-xl font-semibold">Souk Bezzazine</h4>
          <p><strong>Description :</strong> Vannerie, osier. Paniers faits main.</p>
          <p><strong>Idéal pour :</strong> Paniers, objets en osier.</p>
        </div>
        
        <div className="mb-4 p-4 border-l-4 border-blue-500 bg-blue-50">
          <h4 className="text-xl font-semibold">Bab el Jdid</h4>
          <p><strong>Description :</strong> Instruments de musique, marché aux puces.</p>
          <p><strong>Idéal pour :</strong> Instruments traditionnels, antiquités.</p>
        </div>

        <div className="mb-4 p-4 border-l-4 border-blue-500 bg-blue-50">
          <h4 className="text-xl font-semibold">Souk Nejjarine</h4>
          <p><strong>Description :</strong> Ateliers de menuiserie.</p>
          <p><strong>Idéal pour :</strong> Objets en bois sculpté.</p>
        </div>

        <div className="mb-4 p-4 border-l-4 border-blue-500 bg-blue-50">
          <h4 className="text-xl font-semibold">Souk Sebat</h4>
          <p><strong>Description :</strong> Chaussures, tissus, vêtements.</p>
          <p><strong>Idéal pour :</strong> Babouches, tissus, vêtements.</p>
        </div>

        <div className="p-4 border-l-4 border-blue-500 bg-blue-50">
          <h4 className="text-xl font-semibold">Souk el Herir</h4>
          <p><strong>Description :</strong> Tissus soyeux.</p>
          <p><strong>Idéal pour :</strong> Soieries.</p>
          <p className="mt-2"><strong>Artisanat général à Meknès :</strong> Damasquinage, broderie, tannerie.</p>
        </div>
      </div>

      {/* Fès */}
      <div>
        <h3 className="text-2xl font-semibold mb-3 text-blue-600">Marchés et Souks à Fès</h3>
        <p className="mb-2 italic">Informations basées sur Barcelo.com et autres sources. Fès El Bali est un immense marché.</p>

        <div className="mb-4 p-4 border-l-4 border-blue-500 bg-blue-50">
          <h4 className="text-xl font-semibold">Souk au Henné</h4>
          <p><strong>Description :</strong> Henné, cosmétiques naturels.</p>
          <p><strong>Idéal pour :</strong> Henné, khôl, ghassoul.</p>
        </div>

        <div className="mb-4 p-4 border-l-4 border-blue-500 bg-blue-50">
          <h4 className="text-xl font-semibold">Kiseria Al Kifah</h4>
          <p><strong>Description :</strong> Plus ancien souk de Fès, rénové. Grand Bazar.</p>
          <p><strong>Idéal pour :</strong> Artisanat divers, tissus, souvenirs.</p>
        </div>

        <div className="mb-4 p-4 border-l-4 border-blue-500 bg-blue-50">
          <h4 className="text-xl font-semibold">Souk des Chaudronniers (Place Seffarine)</h4>
          <p><strong>Description :</strong> Travail du cuivre, laiton. Théières, bols.</p>
          <p><strong>Idéal pour :</strong> Articles en cuivre et laiton.</p>
        </div>

        <div className="mb-4 p-4 border-l-4 border-blue-500 bg-blue-50">
          <h4 className="text-xl font-semibold">Souk Aïn Allou</h4>
          <p><strong>Description :</strong> Produits en cuir.</p>
          <p><strong>Idéal pour :</strong> Babouches, sacs en cuir, poufs.</p>
        </div>

        <div className="mb-4 p-4 border-l-4 border-blue-500 bg-blue-50">
          <h4 className="text-xl font-semibold">Souk Attarine (Marché aux épices)</h4>
          <p><strong>Description :</strong> Épices, olives, fruits secs.</p>
          <p><strong>Idéal pour :</strong> Épices, ras el hanout.</p>
        </div>

        <div className="mb-4 p-4 border-l-4 border-blue-500 bg-blue-50">
          <h4 className="text-xl font-semibold">Souk Chemainne</h4>
          <p><strong>Description :</strong> Fruits secs, nougat.</p>
          <p><strong>Idéal pour :</strong> Dattes, amandes, nougat de Fès.</p>
        </div>

        <div className="mb-4 p-4 border-l-4 border-blue-500 bg-blue-50">
          <h4 className="text-xl font-semibold">Souk Nejjarine (Souk des Ébénistes)</h4>
          <p><strong>Description :</strong> Objets en bois. Près du Musée Nejjarine.</p>
          <p><strong>Idéal pour :</strong> Coffrets, plateaux en bois sculpté.</p>
        </div>
        <p className="mt-2 p-4 border-l-4 border-blue-500 bg-blue-50"><strong>Autres souks à Fès :</strong> Souk Achebine (volailles), Souk Sekkatine (équipements chevaux), Souk Bellagine (ancien souk serrures), Souk Serrajine, Souk Haïk, Mellah Souk.</p>
        <p className="mt-2 p-4 border-l-4 border-blue-500 bg-blue-50"><strong>Produits typiques de Fès :</strong> Cuir, poterie bleue, tissus, épices, produits de beauté naturels, artisanat en bois et métal, tapis.</p>
        <p className="mt-2 p-4 border-l-4 border-red-500 bg-red-50"><strong>Conseil général pour Fès :</strong> La médina est un labyrinthe. Négociez avec calme et respect.</p>
      </div>

    </div>
  );
};

export default MarchesSouksInfo;

