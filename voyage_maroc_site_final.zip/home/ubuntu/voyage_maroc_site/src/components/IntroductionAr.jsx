import React from 'react';

const IntroductionAr = () => {
  return (
    <section id="introduction-ar" className="py-8" dir="rtl">
      <h2 className="text-3xl font-bold mb-4 text-center">مقدمة</h2>
      <p className="text-lg text-gray-700 leading-relaxed">
        مرحباً بكم في المغرب! تم تصميم هذا البرنامج السياحي لمدة 5 أيام ليقدم لكم لمحة جميلة عن الثروات التاريخية والطبيعية والثقافية للبلاد، مع الانطلاق كل يوم من مكان إقامتكم في الرباط. سوف تستكشفون العاصمة والمدن الإمبراطورية مكناس وفاس، بينما تكتشفون مناظر طبيعية متنوعة وبعض الجواهر الأقل شهرة.
      </p>
    </section>
  );
};

export default IntroductionAr;

