# Site Web Itinéraire Maroc

Ce projet est une application React (Vite + Tailwind CSS) présentant un itinéraire de voyage de 5 jours au Maroc, avec des informations sur les sites à visiter, les hammams, les marchés et des suggestions de cadeaux. Le site est disponible en français et en arabe.

## Structure du Projet

```
/voyage_maroc_site
|-- /dist/                  # Fichiers de build pour le déploiement
|-- /public/                # Fichiers statiques
|-- /src/
|   |-- /components/        # Composants React (FR et AR)
|   |-- App.jsx             # Composant principal de l'application
|   |-- index.css           # Styles globaux (Tailwind)
|   |-- main.jsx            # Point d'entrée de l'application
|-- .eslintrc.cjs
|-- .gitignore
|-- index.html              # Template HTML principal
|-- package.json
|-- pnpm-lock.yaml
|-- postcss.config.js
|-- README.md               # Ce fichier
|-- tailwind.config.js
|-- vite.config.js
```

## Prérequis

- Node.js (version 18 ou supérieure recommandée)
- pnpm (gestionnaire de paquets)

## Installation Locale

1.  **Décompressez l'archive** `voyage_maroc_site_final.zip`.
2.  Ouvrez un terminal et naviguez jusqu'au dossier `voyage_maroc_site`.
3.  **Installez les dépendances** avec pnpm :
    ```bash
    pnpm install
    ```

## Lancement en Mode Développement

Pour lancer le site sur un serveur de développement local (généralement `http://localhost:5173`) :

```bash
pnpm run dev
```

Le site se mettra à jour automatiquement si vous modifiez les fichiers sources.

## Génération des Fichiers pour la Production (Build)

Pour générer les fichiers statiques optimisés pour la production dans le dossier `dist/` :

```bash
pnpm run build
```

## Déploiement

Le dossier `dist/` contient tous les fichiers statiques nécessaires pour déployer le site web.

1.  **Déploiement Statique :** Vous pouvez déployer le contenu du dossier `dist/` sur n'importe quel hébergeur de sites statiques (par exemple : Netlify, Vercel, GitHub Pages, AWS S3, etc.).
    *   Assurez-vous que votre hébergeur est configuré pour servir `index.html` comme point d'entrée.
    *   Si vous utilisez un sous-répertoire (par exemple, `votredomaine.com/voyage-maroc/`), vous devrez peut-être ajuster la propriété `base` dans `vite.config.js` avant de lancer `pnpm run build` :
        ```javascript
        // vite.config.js
        export default defineConfig({
          // ... autres configurations
          base: 
'/voyage-maroc/", // Remplacez par votre sous-répertoire
        });
        ```

## Fonctionnalités

-   Itinéraire détaillé sur 5 jours.
-   Informations sur les sites historiques et naturels.
-   Suggestions de hammams traditionnels.
-   Recommandations de marchés et souks pour le shopping.
-   Idées de cadeaux typiquement marocains.
-   Interface multilingue (Français / Arabe) avec sélecteur de langue.
-   Navigation entre les différentes sections du voyage.

## Personnalisation

-   **Contenu :** Le contenu textuel se trouve principalement dans les fichiers `.jsx` du dossier `src/components/`. Vous pouvez modifier directement ces fichiers pour mettre à jour les informations.
    -   Les fichiers se terminant par `Ar.jsx` contiennent le contenu en arabe.
-   **Styles :** Les styles sont gérés avec Tailwind CSS. Vous pouvez modifier les classes Tailwind directement dans les composants ou ajuster la configuration dans `tailwind.config.js`.

N'hésitez pas à explorer le code source pour des personnalisations plus avancées.

